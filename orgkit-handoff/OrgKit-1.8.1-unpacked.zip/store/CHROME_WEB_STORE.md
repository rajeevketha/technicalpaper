# Chrome Web Store — OrgKit 1.8.1

**Submission pack:** [`extension/store/submission/`](./submission/)  
**Upload zip:** `OrgKit-1.8.1-store.zip`  
**Privacy:** https://rajeevketha.github.io/chromeplugins/extension/privacy.html  

Start with [`submission/SUBMIT_CHECKLIST.md`](./submission/SUBMIT_CHECKLIST.md).

## Snapshot

- MV3 · version **1.8.1**
- Permissions: `cookies`, `storage` (+ Salesforce hosts; OpenAI optional)
- UI: `app/index.html` — **Session Workbench** home (Continue, pinned SOQL, scratch pad) + **Org Compare**
- Custom objects searchable in Describe / SOQL / Permissions
- Deploy Readiness removed
